//
//  Generated file. Do not edit.
//

// clang-format off

#include "generated_plugin_registrant.h"

#include <federated_plugin_windows/federated_plugin_windows_plugin.h>

void RegisterPlugins(flutter::PluginRegistry* registry) {
  FederatedPluginWindowsPluginRegisterWithRegistrar(
      registry->GetRegistrarForPlugin("FederatedPluginWindowsPlugin"));
}
