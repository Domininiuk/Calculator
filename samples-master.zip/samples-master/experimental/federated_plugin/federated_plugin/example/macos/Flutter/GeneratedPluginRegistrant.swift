//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import federated_plugin_macos

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  FederatedPluginMacosPlugin.register(with: registry.registrar(forPlugin: "FederatedPluginMacosPlugin"))
}
