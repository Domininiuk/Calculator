package dev.flutter.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
