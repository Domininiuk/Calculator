# federated_plugin_example

Demonstrates how to use the federated_plugin plugin.
