#import <Flutter/Flutter.h>

@interface FederatedPlugin : NSObject<FlutterPlugin>
@end
