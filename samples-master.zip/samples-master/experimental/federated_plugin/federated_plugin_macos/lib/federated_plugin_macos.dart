// The federated_plugin_macos uses the default BatteryMethodChannel used by
// federated_plugin_platform_interface to do platform calls.
