# federated_plugin_macos_example

To view the usage of plugin, head over to [federated_plugin/example](../../federated_plugin/example).
