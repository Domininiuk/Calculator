// Copyright 2019 The Flutter team. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// TODO: Retrieve an API Access Key from https://unsplash.com/developers
const String unsplashAccessKey = '';

// The application name for the above API Access Key.
const unsplashAppName = '';
