# Photo Search app

This is the Photo Search app, built out with two different widget sets:

  - [Material](material) shows the Photo Search app built with Material widgets
  - [Fluent UI](fluent_ui) shows the Photo Search app built with [Fluent UI][] widgets

[Fluent UI]: https://pub.dev/packages/fluent_ui