# android_using_prebuilt_module

An example Android application used in the Flutter add-to-app samples. For more
information on how to use it, see the [README](../README.md) file located in the
[/add_to_app](/add_to_app) directory of this repo.

## Getting Started

For more information about Flutter, check out
[flutter.dev](https://flutter.dev).

For instructions on how to integrate Flutter modules into your existing
applications, see Flutter's
[add-to-app documentation](https://flutter.dev/docs/development/add-to-app).
