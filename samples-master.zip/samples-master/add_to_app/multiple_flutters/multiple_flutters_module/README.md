# multiple_flutters_module

This is the Flutter module that is embedded in the `multiple_flutters` projects.

See also: [multiple_flutters/README.md](../README.md)