# flutter_module_using_plugin

An example Flutter module that uses a native plugin, intended for use in the
Flutter add-to-app samples. For more information on how to use it, see the
[README.md](../README.md) parent directory.

## Getting Started

For more information about Flutter, check out
[flutter.dev](https://flutter.dev).

For instructions on how to integrate Flutter modules into your existing
applications, see Flutter's
[add-to-app documentation](https://flutter.dev/docs/development/add-to-app).
